const Product = require('../model/product.model');

exports.getAllProducts = async (req, res) => {
  try {
    const products = await Product.find().sort({ ProductStoreCode: -1 });
    res.render('home', { products });
  } catch (err) {
    res.status(500).send(err);
  }
};

exports.createProduct = async (req, res) => {
  try {
    const newProduct = new Product(req.body);
    await newProduct.save();
    res.redirect('/');
  } catch (err) {
    res.status(400).send(err);
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const deletedProduct = await Product.findOneAndDelete({ ProductCode: req.params.productCode });
    if (!deletedProduct) {
      return res.status(404).send({ error: 'Không tìm thấy sản phẩm' });
    }
    res.redirect('/');
  } catch (err) {
    res.status(500).send(err);
  }
};
