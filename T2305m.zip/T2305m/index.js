const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const productRoutes = require('./router/productRoute');

const app = express();
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.use(express.static("public"));

app.use('/', productRoutes);

const port = 2305;
app.listen(port,function(){
    console.log("Server is running....");
});
require("./model/database");
