const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const product_Controller = require('../controller/product.controller');

router.get('/', product_Controller.getAllProducts);
router.post('/product/add', product_Controller.createProduct);
router.delete('/:productCode', product_Controller.deleteProduct);
module.exports = router;
